﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Missingpersondata
/// </summary>
public class Missingpersondata
{
	public Missingpersondata()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}